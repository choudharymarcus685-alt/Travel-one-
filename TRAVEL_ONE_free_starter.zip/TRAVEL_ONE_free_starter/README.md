# TRAVEL ONE — Free Starter Prototype

Open `index.html` in a browser. It is a no-build, static multi-page prototype with separate navigation pages.

## Free use
- No Lovable credits are needed to edit this starter.
- You can open it locally without paying.
- Static hosting may be available on free tiers (for example GitHub Pages), subject to each provider's limits and terms.

## Important limitations
This is a front-end demo, not a production travel platform. It does not connect to live flight/hotel bookings, official visa or airport systems, payments, AI services, real ad delivery/analytics, emergency services, secure accounts, or encrypted document storage. Do not upload real identity documents or rely on demo emergency information.
